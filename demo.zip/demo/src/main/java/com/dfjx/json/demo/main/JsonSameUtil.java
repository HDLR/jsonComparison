package com.dfjx.json.demo.main;

import com.google.gson.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class JsonSameUtil {

    public static final Gson gson = new Gson();
    public static final JsonParser parser = new JsonParser();

    public static boolean same(Object a, Object b){
        if(a == null){
            System.out.println("Object内容都为空");
            return b == null;
        }
        return same(gson.toJson(a), gson.toJson(b));
    }

    public static boolean same(String a, String b){
        if(a == null){
            System.out.println("String内容都为空");
            return b == null;
        }
        if(a.equals(b)){
            if(a.indexOf("[") == 0){
                return same(new JsonParser().parse(a).getAsJsonArray(), new JsonParser().parse(b).getAsJsonArray());
            }else if(a.indexOf("{") == 0){
                return same(new JsonParser().parse(a).getAsJsonObject(), new JsonParser().parse(b).getAsJsonObject());
            }
            System.out.println("String【" + a + "】 与 【" + b + "】 相等");
            System.out.println("String【" + a + "】");
            System.out.println("String【" + b + "】");
            return true;
        }
        JsonElement aElement = parser.parse(a);
        JsonElement bElement = parser.parse(b);

        if(gson.toJson(aElement).equals(gson.toJson(bElement))){
            System.out.println("JsonElement【" + a + "】 与 【" + b + "】 相等");
            return true;
        }
        return same(aElement, bElement);
    }

    private static boolean same(JsonElement a, JsonElement b){
        if(a.isJsonObject() && b.isJsonObject()){

//            System.out.println("isJsonObject()");
            return same((JsonObject) a, (JsonObject) b);
        }else if(a.isJsonArray() && b.isJsonArray()){

//            System.out.println("isJsonArray()");
            return same((JsonArray) a, (JsonArray) b);
        }else if(a.isJsonPrimitive() && b.isJsonPrimitive()){

//            System.out.println("isJsonPrimitive()");
            return same((JsonPrimitive) a, (JsonPrimitive) b);
        }else if(a.isJsonNull() && b.isJsonNull()){

//            System.out.println("isJsonNull()");
            return same((JsonNull) a, (JsonNull) b);
        }else{
            System.out.println("JsonElement类型不相符：" + a + "------------" + b);
            return Boolean.FALSE;
        }
    }

    private static boolean same(JsonObject a, JsonObject b){
        Set<String> aSet = a.keySet();
        Set<String> bSet = b.keySet();
        if(!aSet.equals(bSet)){
            System.out.println("Set值不相等：" + aSet + "------------" + bSet);
            return false;
        }
        for(String aKey : aSet){
            if(!same(a.get(aKey), b.get(aKey))){
                System.out.println(aKey + "对应的值不相等：" + a.get(aKey) + "------------" + b.get(aKey));
                return false;
            }
        }
        return true;
    }

    private static boolean same(JsonArray a, JsonArray b){
        if(a.size() != b.size()){
            System.out.println("size不相等：" + a.size() + "------------" + b.size());
            return false;
        }
        List<JsonElement> aList = toSortedList(a);
        List<JsonElement> bList = toSortedList(b);
        for(int i=0; i<aList.size(); i++){
            if(!same(aList.get(i), bList.get(i))){
                System.out.println("aList.get(i)不相等：" + aList.get(i) + "------------" + bList.get(i));
                return false;
            }
        }
        return true;
    }

    private static boolean same(JsonPrimitive a, JsonPrimitive b){
        boolean flag = a.equals(b);
        if(!flag){
            System.out.println("\033[31;4m" + "【"+ a +"】 不相等 【"+ b +"】" + "\033[0m");
        }
//        System.out.println("JsonPrimitive值比较：" + flag);
        return flag;
    }

    private static boolean same(JsonNull a, JsonNull b) {
        System.out.println("都为JsonNull");
        return true;
    }

    private static List<JsonElement> toSortedList(JsonArray a){
        List<JsonElement> aList = new ArrayList<>();
        a.forEach(aList::add);
        aList.sort(Comparator.comparing(gson::toJson));
        return aList;
    }
}
